# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=Kernel Selinux Permissive Setter
do.devicecheck=0
do.modules=0
do.cleanup=1
do.cleanuponabort=0
supported.versions=
'; } # end properties

# shell variables
block=boot;
is_slot_device=auto;
ramdisk_compression=none;

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

## AnyKernel install
split_boot;

# begin ramdisk changes
patch_cmdline androidboot.selinux androidboot.selinux=permissive

flash_boot;
## end install

