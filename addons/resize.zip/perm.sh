#!/sbin/sh

mount /optics
mount -o rw,remount /optics
exit 0