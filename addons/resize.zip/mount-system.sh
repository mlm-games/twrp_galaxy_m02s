#!/sbin/sh
umount /system_root
umount /product
umount /vendor
chmod 755 system/jdm_a05m/lptools_new
  ./system/jdm_a05m/lptools_new --super /dev/block/by-name/super --resize product 1554931
  ./system/jdm_a05m/lptools_new --super /dev/block/by-name/super --resize system 3355443200

exit 0
